﻿using UnityEngine;
using System.Collections;

public class gControl : MonoBehaviour {

	public GameObject ball;
	int spawnTimer;

	// Use this for initialization
	void Start () {
	
		spawnTimer = 100;

	}
	
	// Update is called once per frame
	void Update () {
		if (spawnTimer >= 0)
			spawnTimer -= 1;
		else
			spawnTimer = 100;

		if (spawnTimer == 0)
			Spawn ();
	
	}

	void Spawn()
	{
		Vector3 pos = new Vector3 (0,5,0);
		Instantiate(ball,pos,Quaternion.identity);
	}

}
