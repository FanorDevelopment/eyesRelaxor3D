﻿using UnityEngine;
using System.Collections;

public class ballMover : MonoBehaviour {

	Rigidbody rb;
	float speed;
	float timer;
	int switcher;

	// Use this for initialization
	void Start () {
		rb = gameObject.GetComponent<Rigidbody>();
		speed = 10500;
		ColorChoice ();

	}
	
	// Update is called once per frame
	void Update () {

		timer = Random.Range (1, 5);

		if(timer>=0)
			timer -= 0.01f;
		else
			timer = Random.Range (1, 5);

		switcher = Random.Range (1, 5);



		switch (switcher) 
		{
		case 1:
			rb.AddForce (Vector3.left * Time.deltaTime * speed);
			break;
		case 2:
			rb.AddForce (Vector3.right*Time.deltaTime*speed);
			break;
		case 3:
			rb.AddForce (Vector3.forward*Time.deltaTime*speed);
			break;
		case 4:
			rb.AddForce (Vector3.back*Time.deltaTime*speed);
			break;
		default:
			rb.AddForce (Vector3.back*Time.deltaTime*speed);
			break;
		}
	
		print (timer);
		print(switcher);

	}

	void ColorChoice()
	{
		int col = Random.Range(1,5);

		switch(col)
		{
		case 1:
			gameObject.GetComponent<Renderer>().material.color = Color.red;
			break;
		case 2:
			gameObject.GetComponent<Renderer>().material.color = Color.yellow;
			break;
		case 3:
			gameObject.GetComponent<Renderer>().material.color = Color.blue;
			break;
		case 4:
			gameObject.GetComponent<Renderer>().material.color = Color.green;
			break;
		default:
			gameObject.GetComponent<Renderer>().material.color = Color.black;
			break;
		}
	}
}
